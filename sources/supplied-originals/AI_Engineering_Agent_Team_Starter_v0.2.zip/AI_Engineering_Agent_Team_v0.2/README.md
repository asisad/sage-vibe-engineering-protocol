# AI Engineering Agent Team — SAGE Starter v0.2

**Parent architecture:** SAGE — SiSsad Agentic General Engineering  
**Subsystem:** SENS — SiSsad Engineering Nervous System (observer/analysis only)  
**Status:** Portable **role/skill configuration templates**, not instantiated agents, not installed into SAGE/SENS, and no physical devices or deployments controlled.

This is an **incremental update to v0.1**. It preserves the language engineering roles and adds six specialist capability families: Docker/DevOps, Embedded/IoT, Robotics/Actuation, CNC/G-code, Automation/IaC, and FPGA/HDL. Do not confuse an ecosystem/tool/platform or controller DSL with a general-purpose programming language.

## Ownership boundary — MUST NOT CHANGE
- **SAGE owns**: engineering constitution, SDAE/spec-driven process, architecture source of truth, orchestrator, Agent/Model Fabric, Skill Router, Tool/MCP integrations, code changes, verification and approvals.
- **SENS owns**: passive evidence collection, low-overhead telemetry, UEG/CMDB/knowledge/code/decision graphs, run logs, impact analysis, drift findings and SEOv observability views. SENS does **not** own the engineering orchestrator, specialist agents or physical actuators.
- **Bridge**: SAGE emits bounded, nonblocking events to SENS; SENS returns analysis/advice/evidence references. SAGE independently reviews, authorizes and enacts any change. SENS fails open and cannot block business workflows. See `docs/SAGE_SENS_INTEGRATION.md`.
- Distinct projects such as Blender/SketchUp bridges or a dedicated architecture application are not collapsed into SENS; SAGE specialists may contribute to them via explicit project integrations.

## Included
- `AGENTS.md`: mergeable repository-wide engineering policy.
- `agents/`: **role blueprints** and a SAGE-oriented router. These are not running agents.
- `skills/*/SKILL.md`: portable, load-on-demand workflows. Actual discovery depends on the compatible runtime/harness.
- `docs/ARCHITECTURE_FA.md`: updated Persian master blueprint (v0.2).
- `docs/SAGE_SENS_INTEGRATION.md`: architecture ownership, information flow and telemetry contract.
- `docs/CAPABILITY_CATALOG_FA.md`: languages vs. DSL vs. ecosystems vs. infrastructure and on-demand specialist priority.
- `docs/SOURCES.md`: authoritative external documentation entry points and version caveats.
- `quality/`: acceptance and safety gates with simulator/physical-system separation.
- `templates/`: development task request plus physical automation task brief.
- `knowledge/`: reusable, source-versioned patterns once populated.
- `manifest.json`: descriptive routing metadata, **not** an execution manifest.

## Safe adoption
1. Keep `v0.1` for provenance; review changes before copying `v0.2` into the appropriate **SAGE** repository.
2. Merge `AGENTS.md` with the repo's existing constitution and instructions; never replace those blindly.
3. Register each `skills/*/SKILL.md` and `agents/*.md` through your orchestrator's supported mechanisms.
4. Start with just core SAGE developers and QA; invoke specialist skills on demand. Avoid dozens of always-on agents.
5. Grant read-only access first; sandbox compilation, simulation and dry-run checks. Grant no unconditional Docker daemon, Kubernetes, serial port, GPIO, machine control, secrets, registry or production access.
6. Obtain explicit human approval before flashing, uploading firmware, moving motors, executing G-code, applying IaC, deploying, publishing or deleting resources; respect physical E-stop, interlocks and machine-specific procedures.
7. Only emit sanitized, bounded, out-of-band agent execution evidence to SENS; preserve provenance and a strict telemetry budget.
8. Pilot in a disposable repository and with simulated hardware before considering production integration.

No credential is stored in the archive. No code was deployed, compiled on a target board, or tested against physical hardware.
