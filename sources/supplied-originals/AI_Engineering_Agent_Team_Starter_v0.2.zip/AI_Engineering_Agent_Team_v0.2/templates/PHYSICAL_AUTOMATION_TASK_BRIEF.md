# SAGE Physical / IoT / CNC Task Brief (fill only known values)

- Project/task:
- Requested output: [ ] description [ ] source code [ ] compiled artifact [ ] simulator run [ ] physical operation
- Hardware / board / SoC / controller exact model:
- Firmware / toolchain / G-code dialect and versions:
- Wiring diagram, pins, driver and voltage/current ratings:
- Motion axis travel, speed/acceleration, payload/tool, units and coordinates:
- End stops / interlock / watchdog / E-stop / stop procedure:
- Acceptance tests: offline compile + simulation + expected results:
- Available simulator/emulator/device: 
- Physical execution authorized? **DEFAULT NO** — separate explicit scoped approval required:
- Any production infrastructure/cloud/device network access authorized? **DEFAULT NO**:
- SENS telemetry budget, privacy classes, redaction policy:
- Source-of-truth docs and design revision:
- Definition of Done and known hazards:
