# Engineering Task Brief

- **Requested outcome:**
- **Repository / commit / branch:**
- **Allowed files / working area:**
- **Target OS/runtime / version:**
- **Existing dependencies / lockfiles:**
- **Performance budget (CPU, memory, network, p95):**
- **Security/privacy constraints:**
- **Required API / integration contracts:**
- **Acceptance tests:**
- **Approvals granted:**
- **Non-goals:**
- **Deliverables:**
