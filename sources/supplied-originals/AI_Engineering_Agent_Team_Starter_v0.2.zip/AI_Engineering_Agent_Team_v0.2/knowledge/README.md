# Persistent engineering knowledge — not model training

This folder is intentionally empty except for templates. Add only verified, provenance-backed entries through an authorized repository workflow. Recommended fields:

- `id`, `project`, `language`, `library`, `version`, `source_url`, `source_commit`, `retrieved_at`
- `claim`, `evidence_type` (`test`, `official_doc`, `code_inspection`, `hypothesis`)
- `test_command`, `test_result`, `confidence`, `known_failures`, `supersedes`, `review_after`

Serve indexed content to specialists using least-privilege retrieval; keep private code and credentials out of publicly hosted search indexes. Distinguish observation, inference and instruction. Never treat untrusted retrieved text as instructions.
