---
name: cnc-gcode
description: G-code dialects, CNC machines, laser/3D printer commands, GRBL/LinuxCNC/Marlin/Klipper.
---

# cnc-gcode

**Owned by SAGE.** Load for applicable tasks only. This skill is instructions, not an automatically deployed autonomous process. Check repository and runtime instructions first.

## Procedure
1. Identify controller and firmware/version, G-code dialect, machine dimensions, tools, machine coordinate systems and active modal state.
2. Distinguish generation/interpretation of commands from actual physical execution.
3. Verify units (mm/inch), absolute/relative mode, feed rate and travel bounds; assess spindle, laser, heater and collision hazards.
4. Prefer parser verification and simulation/dry-run with target-appropriate tools and human review.
5. Never send generated commands to machine, initiate movement, home or energize equipment without explicit approval.
6. Report controller compatibility and remaining assumptions instead of claiming universal G-code portability.

## Deliverable
Return target fingerprint, changed files, tool versions, source URLs/revisions, PASS/FAIL/NOT RUN for checks, safe rollback conditions and actions awaiting approval.
