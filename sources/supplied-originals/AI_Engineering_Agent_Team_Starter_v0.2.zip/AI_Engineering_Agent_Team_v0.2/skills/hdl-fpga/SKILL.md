---
name: hdl-fpga
description: Verilog/SystemVerilog/VHDL, FPGA simulation, synthesis and timing.
---

# hdl-fpga

**Owned by SAGE.** Load for applicable tasks only. This skill is instructions, not an automatically deployed autonomous process. Check repository and runtime instructions first.

## Procedure
1. Verify target family, clocking, I/O banks, board pin constraints and tool versions.
2. Define RTL function, reset/clock-domain strategy, timing and hardware resource budgets.
3. Write a deterministic testbench and run lint/elaboration/simulation in a sandbox.
4. Assess synthesis and timing closure when correct licensed toolchain is available.
5. Never claim on-hardware pass without an approved device run. Flashing a bitstream must be separately authorized.
6. Report simulation evidence, board-dependent assumptions and safe deployment plan.

## Deliverable
Return target fingerprint, changed files, tool versions, source URLs/revisions, PASS/FAIL/NOT RUN for checks, safe rollback conditions and actions awaiting approval.
