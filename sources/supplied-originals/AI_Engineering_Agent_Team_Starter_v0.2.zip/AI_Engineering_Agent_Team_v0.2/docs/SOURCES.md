# Official source index (reviewed 2026-10-14)

These are entry points, not pinned proof of specific library compatibility. Fetch current/relevant pages at task time.

- Rust book: https://doc.rust-lang.org/book/
- Cargo: https://doc.rust-lang.org/cargo/
- Rust Clippy: https://doc.rust-lang.org/clippy/
- Rust library docs: https://doc.rust-lang.org/std/
- Crate versioned API docs: https://docs.rs/
- Rust MCP SDK: https://docs.rs/rmcp/latest/rmcp/
- Go docs: https://go.dev/doc/
- C# docs: https://learn.microsoft.com/en-us/dotnet/csharp/
- Python docs: https://docs.python.org/3/
- TypeScript docs: https://www.typescriptlang.org/docs/
- Node.js docs: https://nodejs.org/en/learn
- Three.js docs: https://threejs.org/docs/
- Godot docs: https://docs.godotengine.org/
- Blender Python API: https://docs.blender.org/api/current/
- Zig docs: https://ziglang.org/documentation/
- Mojo docs: https://docs.modular.com/mojo/manual/
- MCP specification: https://modelcontextprotocol.io/specification/
- AGENTS.md format: https://agents.md/
- OpenAI agent skills: https://developers.openai.com/api/docs/guides/tools-skills
- OpenAI agent orchestration: https://openai.github.io/openai-agents-python/multi_agent/
- OpenAI Agents SDK: https://openai.github.io/openai-agents-python/

Docs and package versions are subject to change. Do not rely on this index instead of checking runtime/current version.

## Additional domain / platform sources for SAGE v0.2 (reviewed 2026-10-14)
- Dockerfile official guide: https://docs.docker.com/get-started/docker-concepts/building-images/writing-a-dockerfile/
- Docker Compose model: https://docs.docker.com/compose/intro/compose-application-model/
- Arduino sketch compilation (.ino to C++): https://docs.arduino.cc/arduino-cli/sketch-build-process
- Arduino CLI compile: https://docs.arduino.cc/arduino-cli/commands-reference/arduino-cli_compile
- Arduino CLI upload (separate from compile): https://docs.arduino.cc/arduino-cli/commands-reference/arduino-cli_upload
- Espressif official stable ESP-IDF: https://docs.espressif.com/projects/esp-idf/en/stable/esp32/
- Rust on ESP resource index: https://esp-rs.github.io/
- esp-hal target-specific API: https://docs.rs/esp-hal/latest/esp_hal/
- MicroPython ESP32 reference: https://www.micropython.org/resources/docs/en/latest/esp32/quickref.html
- LinuxCNC G-code reference: https://www.linuxcnc.org/docs/html/gcode.html
- Terraform language/HCL: https://developer.hashicorp.com/terraform/language
- Zephyr supported boards: https://docs.zephyrproject.org/latest/boards/

**Version caveat:** official 'latest' docs may not match pinned deployed tools. ESP32 variants use distinct HAL features/pins; G-code dialects are controller-dependent.
