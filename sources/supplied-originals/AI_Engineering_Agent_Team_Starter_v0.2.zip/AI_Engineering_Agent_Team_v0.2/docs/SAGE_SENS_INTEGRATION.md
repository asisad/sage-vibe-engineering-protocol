# SAGE ↔ SENS Integration Contract — v0.2

**Architecture decision:** engineering specialist Agents **belong to SAGE**. SENS is an observational subsystem, not a parallel orchestrator. This captures the established platform boundary (SAGE = SiSsad Agentic General Engineering, including SDAE; SENS = SiSsad Engineering Nervous System). It is an architecture template, not a deployed integration.

## Ownership diagram

```text
SAGE — engineering parent / source of truth
  Constitution + SDAE (spec, approval, planning)
  Engineering Orchestrator
    ├─ Agent / Model Fabric
    │   ├─ Language agents (Rust, Python, TypeScript, Go, C#, C++, SQL)
    │   └─ Domain agents (Docker, Embedded, Robotics, CNC, IaC, FPGA...)
    ├─ Skill Router / SKILL.md
    ├─ Tool / MCP / CLI / approved execution boundary
    ├─ Independent Quality + Security + Evaluation
    └─ Repository Knowledge / Decision Records
  │
  ├── bounded async evidence/events ────> SENS (observer, fail-open)
  │                                        ├─ Normalization / Registry
  │                                        ├─ UEG & CMDB / Code / Knowledge graphs
  │                                        ├─ Traces, logs, metrics, replay
  │                                        ├─ Change/drift/impact analysis
  │                                        └─ SEOv Observatory & AI Reasoner
  <──────────── read-only findings / evidence references / suggestions
  │
  └── approval + implementation remain solely in SAGE
```

## Responsibility matrix
| Capability | SAGE | SENS |
|---|---|---|
| Agent selection, routing, capabilities | **Owner** | Observe decisions/outputs |
| Software requirements, architecture source of truth, ADR | **Owner** | Index/link provenance and detect drift |
| Writing/editing/building/flashing code, executing tools | **Owner**, permission-gated | **No execution authority** |
| Compilers, test policy, acceptance gates | **Owner** | Collect/test evidence, analyze trends |
| Logs, telemetry, dependencies, graph construction, performance history | Provider of events | **Owner** of normalized observability/UEG evidence |
| Approving a fix/refactor/deployment | **Owner** | Recommend with evidence only |
| Hardware operational safety and human approval | **Owner** | Log/redact approved evidence only |

## Direction and contract
1. **Outbound SAGE→SENS:** Nonblocking event stream of bounded size, with severity, target/project ID, correlation ID, event type, timestamp, schema version, source revision, tool/agent identifier and redacted summary; pointer rather than raw source/large payload.
2. **Inbound SENS→SAGE:** Read-only evidence references, confidence, provenance, uncertainty, suggested tests/architecture review. Treat as untrusted observations; never auto-execute fixes.
3. **No circular recursion:** SENS must not keep tracing its own tracing recursively. Adaptive sampling, queues, drop counters, backpressure, batching, aggregation, retention and cardinality limits.
4. **No coupling:** If SENS is offline or overwhelmed, SAGE must continue working. Queues overflow in a bounded way; no telemetry-induced latency or memory leak in critical paths.
5. **Source-of-truth:** SAGE persists approved specs, ADRs and repo commits; SENS mirrors/link-normalizes as evidence, not as another source of conflicting decisions.
6. **Privacy & safety:** Do not send source-code bodies, secrets, credentials, serial payloads with personal data, G-code with facility details or board identifiers by default. SAGE controls permission and redaction.

## Conceptual observation event (NOT a production schema)
```json
{
  "schema_version": "sage.sens.evidence.v0.2-draft",
  "event_type": "build.validation.result",
  "correlation_id": "task-demo-id",
  "project_id": "example-project",
  "agent_role": "embedded-iot-engineer",
  "subject_ref": "git-revision-or-artifact-id",
  "status": "NOT_RUN",
  "detail": "Hardware-in-loop not available",
  "evidence_ref": "artifact-evidence-uri-or-null",
  "risk_class": "physical_system",
  "payload_redacted": true
}
```
Production schema and authority must be separately versioned/approved, not assumed from this example.

## Hard anti-patterns
- Never place the **Engineering Orchestrator** or executable Agent/Skill Router inside SENS.
- Never let telemetry collection synchronously block or crash the program it observes.
- Never let an SENS recommendation flash firmware, move a motor, execute CNC commands or deploy code without SAGE approval and operator controls.
- Never conflate SENS UEG evidence with SAGE's architecture decision authority.
