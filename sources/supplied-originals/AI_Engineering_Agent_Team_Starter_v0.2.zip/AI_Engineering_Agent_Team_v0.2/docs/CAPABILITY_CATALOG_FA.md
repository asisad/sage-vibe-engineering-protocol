# کاتالوگ فناوری و تخصص‌های SAGE — نسخه 0.2

**موضوع:** دسته‌بندی صحیح زبان‌ها، ابزارها، DSLها، سکوها و کنترل سخت‌افزار. فهرست نمونه است و محدودیت قطعی توانایی AI محسوب نمی‌شود. کیفیت باید با نسخه ابزار و آزمون واقعی اثبات شود.

## دسته‌بندی
| فناوری | ماهیت | فایل/رابط متداول | نقش مسئول پیشنهادی | اولویت استفاده |
|---|---|---|---|---|
| Rust | زبان عمومی/سیستمی | `.rs`, Cargo | rust-engineer | بالا برای SENS hot-path و backend مناسب |
| Python | زبان عمومی، AI و اتوماسیون | `.py` | python-ai-engineer | بسیار بالا |
| TypeScript / JavaScript | زبان‌های وب/ابزارها | `.ts`, `.js` | typescript-web-engineer | بالا |
| Go | زبان عمومی/سرویس و CLI | `.go` | go-engineer | وابسته به پروژه |
| C# / .NET | زبان/چارچوب | `.cs` | csharp-dotnet-engineer | Unity و .NET |
| C / C++ | زبان عمومی/سیستمی | `.c`, `.cpp`, `.h` | cpp-native-engineer | native و embedded |
| SQL | زبان پرس‌وجو | `.sql` | data-sql-engineer | بسیار بالا |
| Docker Engine | **پلتفرم** کانتینر | `docker` CLI | devops-containers-engineer | بسیار بالا برای زیرساخت |
| Dockerfile | DSL دستور ساخت image | `Dockerfile` | devops-containers-engineer | بالا |
| Docker Compose | ابزار مدل‌سازی/اجرا + YAML | `compose.yaml` | devops-containers-engineer | بالا |
| Kubernetes / Helm | پلتفرم ارکستراسیون / بسته‌بندی | YAML، charts | devops-containers-engineer | وابسته به مقیاس |
| Arduino | اکوسیستم سخت‌افزاری/IDE/SDK | `.ino` معمولاً C++ | embedded-iot-engineer | بالا برای نمونه‌سازی |
| ESP32 | خانواده SoC میکروکنترلر (نه زبان) | ESP-IDF/Arduino/MicroPython/Rust | embedded-iot-engineer | بالا برای IoT |
| ESP-IDF | SDK رسمی Espressif (C/C++) | `idf.py`, CMake | embedded-iot-engineer | اولویت فنی ESP32 تولیدی |
| MicroPython / CircuitPython | زبان و runtime پایتونِ MCU | `.py` | embedded-iot-engineer | نمونه‌سازی/سخت‌افزار سازگار |
| Rust Embedded / esp-hal | زبان + HAL مخصوص تراشه | `.rs` | embedded-iot-engineer + rust-engineer | مشروط به پوشش چیپ |
| PWM / I²C / SPI / UART | سیگنال/گذرگاه/رابط سخت‌افزاری | API و درایور | robotics-control-engineer + embedded | مرتبط با سخت‌افزار |
| Servo / Stepper | محرک فیزیکی، نه زبان | driver / PWM / step-dir | robotics-control-engineer | مرتبط با سخت‌افزار |
| G-code | **زبان فرمان دامنه‌محور** حرکت/ماشین | `.gcode`, `.nc`, `.tap` | cnc-gcode-engineer | وابسته به دستگاه |
| GRBL / LinuxCNC / Marlin / Klipper | کنترلر/فریم‌ور/پشته نرم‌افزاری | G-code dialects | cnc-gcode-engineer | وابسته به دستگاه |
| Bash / PowerShell | زبان‌های اسکریپتی/فرمان | `.sh`, `.ps1` | automation-iac-engineer | بالا |
| YAML / JSON / TOML | فرمت داده/پیکربندی | `.yaml`, `.json`, `.toml` | متخصص زمینه | فراگیر؛ Agent مستقل ضروری نیست |
| HCL / Terraform | زبان پیکربندی + ابزار IaC | `.tf` | automation-iac-engineer | پروژه‌محور |
| Ansible | ابزار اتوماسیون پیکربندی | YAML playbook | automation-iac-engineer | پروژه‌محور |
| Verilog/SystemVerilog/VHDL | زبان توصیف/راستی‌آزمایی سخت‌افزار | `.v`, `.sv`, `.vhd` | hdl-fpga-engineer | On-demand |
| Zephyr / FreeRTOS | RTOS/SDK | C/C++, devicetree/Kconfig | embedded-iot-engineer | On-demand |
| ROS 2 / URDF | میان‌افزار رباتیک / توصیف ربات | Python/C++, XML | robotics-control-engineer | On-demand |
| IEC 61131-3 Structured Text / Ladder | زبان‌های PLC صنعتی | vendor-specific | language-researcher + automation/robotics | On-demand و نیازمند تأیید صنعتی |
| Swift / Kotlin / Dart | زبان‌های موبایل/چندسکویی | `.swift`, `.kt`, `.dart` | language-researcher + specialist | هنگام نیاز اپ موبایل |
| GLSL/HLSL/WGSL | زبان Shader | `.glsl`, `.hlsl`, `.wgsl` | graphics-engineer | گرافیک/بازی |
| Zig / Mojo | زبان‌های رو به تکامل | `.zig`, `.mojo` | language-researcher | تحقیق و نمونه آزمایشی |

## اصل تخصص
- برای **هر زبان** یک Agent دائمی ایجاد نکن. متخصص بر اساس دامنه، ابزار و نیاز واقعی فراخوانی شود؛ مثلاً Docker متخصص زیرساخت می‌خواهد نه «زبان Docker».
- برای **سیستم فیزیکی** باید دو قرارداد جدا وجود داشته باشد: «تولید و راستی‌آزمایی برنامه» و «اجرای واقعی/فرمان سخت‌افزار». تأیید اول مجوز دوم نیست.
- برای ESP32 زبان را بعد از انتخاب **تراشه دقیق، سخت‌افزار، توان پردازش، SDK و کتابخانه‌ها** تعیین کن. Rust گزینه بالقوه خوب است ولی C/C++/MicroPython در بسیاری از پروژه‌ها مناسب‌ترند.
- G-code کاملاً context-dependent است: دستگاه، فریم‌ور، پس‌پردازنده، ابزار، وضعیت مودال و محدودیت‌های حرکتی مهم‌اند.

## برنامه پیشنهادی فعال‌سازی
- **هسته همیشه لازم (P0)**: SAGE Orchestrator، Rust، Python، TypeScript، QA. DevOps/Containers و Data/SQL به عنوان قابلیت نزدیک به هسته.
- **On-demand P1**: Go/C#/C++، Embedded/IoT، Robotics، CNC G-code، Automation/IaC و Graphics؛ بسته به کار پروژه.
- **On-demand P2**: HDL/FPGA، PLC، زبان‌های نو و SDKهای خاص. بدون اثبات آزمایشگاهی وارد محصول تولیدی نشوند.

## حداقل شواهد یک متخصص سخت‌افزار
1. نام دقیق برد/تراشه یا کنترلر، firmware version، پین‌مپ و Datasheet.
2. محدوده ولتاژ/جریان/منبع تغذیه و روش قطع اضطراری یا fail-safe.
3. نسخه ابزارها، build log، simulation و test report.
4. صراحت درباره تست‌نشده‌ها؛ عدم اجرای ماشین/برد بدون اجازه.

## منابع رسمی راهنما
- Dockerfile: https://docs.docker.com/get-started/docker-concepts/building-images/writing-a-dockerfile/
- Docker Compose: https://docs.docker.com/compose/intro/compose-application-model/
- Arduino sketch processing: https://docs.arduino.cc/arduino-cli/sketch-build-process
- Arduino compile/upload: https://docs.arduino.cc/arduino-cli/commands-reference/arduino-cli_compile
- ESP-IDF: https://docs.espressif.com/projects/esp-idf/en/stable/esp32/
- ESP Rust: https://esp-rs.github.io/
- MicroPython ESP32: https://www.micropython.org/resources/docs/en/latest/esp32/quickref.html
- LinuxCNC G-code quick reference: https://www.linuxcnc.org/docs/html/gcode.html
- Terraform language: https://developer.hashicorp.com/terraform/language
- Zephyr board support: https://docs.zephyrproject.org/latest/boards/
