# Quality gates and evidence levels

**Not run** must be explicit, and cannot be relabeled Pass.

| Gate | Standard | Evidence |
|---|---|---|
| Version check | Toolchain and target platform recorded | Exact command/output, lockfiles |
| Syntax/build | Compiles for target toolchain | Build log, exit code |
| Behavior | Unit/integration tests, edge cases | Test logs |
| Static checks | Formatter, linter, type checker | Lint/format results |
| Security | Dependencies, secrets, authZ, permissions | Scan result and scope |
| Performance | Compare against unchanged baseline under same conditions | CPU, memory, p95 latency, throughput, drop-rate |
| Architecture | ADR and SENS overhead constraints honored | Review checklist |
| Human approval | Destructive/deploy/publish/cost/secret actions | Approver ID and scope |

Use evidence tiers: **Verified in current environment**, **Documentation-verified only**, **Inference**, **Unverified**.

## New gate: physical / infrastructure risk (SAGE v0.2)
| Risk class | Required validation | Approval gate |
|---|---|---|
| Code-only | Format, build, unit/integration test | Edit authority per repo |
| Docker image/config | Static configuration check, policy/security scan | Build/run and registry/network permissions separately |
| Infra/CI | Plan/diff with scoped credentials and rollback | Explicit approval for apply/deploy/secret-bearing action |
| MCU firmware | Exact board/SoC/FQBN + toolchain build + pin/power checks | Explicit approval for flash/eFuse/OTA/hardware access |
| Servo/robot/stepper | Simulation, bounds/interlocks/watchdog/fail-safe | Explicit operator authorization before energizing/moving |
| CNC/G-code | Controller dialect, modal units, path envelope and dry-run | Explicit authorization before sending/streaming to real machine |
| FPGA RTL | Testbench/synthesis/timing/board constraints | Explicit approval to program bitstream or drive I/O |

Distinguish **Generated**, **Validated Offline**, **Simulated**, **Hardware Verified**, **Deployed**. A result at one level must never be reported as a higher level. SENS may ingest evidence, but SAGE retains decision/approval authority.
