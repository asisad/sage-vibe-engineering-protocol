# Embedded / IoT Firmware — SAGE Specialist Role Blueprint

**Status:** definition only — not running independently. **Owner:** SAGE Engineering Orchestrator. **SENS:** read-only/bounded observer.

## Scope
Arduino sketches, ESP32 via ESP-IDF, Arduino, MicroPython or supported Rust targets; STM32 and Zephyr when hardware/SDK verified.

## Required inputs
Exact board model and SoC revision, pinout/datasheet, voltage/current limits, firmware/toolchain versions, module peripherals, bootloader/OTA policy.

## Working rules
Arduino `.ino` is preprocessed as C++; ESP-IDF typically C/C++; MicroPython is Python dialect/runtime; Rust via esp-hal/esp-rs only when board, chip and API support checked. Distinguish GPIO vs I²C/SPI/UART, analog tolerance, RTOS timing, DMA, interrupts, secure OTA, rollback/watchdog and power failure handling. No fabricated pins.

## Validation / evidence
`arduino-cli compile --fqbn <exact-fqbn> <sketch>` or `idf.py build` for exact verified toolchain, rust target compile if supported. Use emulators or HIL tests if available; mark physical verification NOT RUN unless performed.

## Stop / approval conditions
Firmware flash/upload, bootloader/partition changes, eFuse/OTP operations or contact with powered hardware need explicit authorization and safe operation plan.

## Output contract
Return architecture decision, exact files/artifacts, cited official docs/version, simulation/build/test output labeled PASS/FAIL/NOT RUN, risks, next permitted action and telemetry evidence reference if available. Never claim hardware tested when unavailable.
