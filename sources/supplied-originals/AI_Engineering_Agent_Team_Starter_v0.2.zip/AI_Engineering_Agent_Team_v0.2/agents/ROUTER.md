# Engineering Orchestrator — SAGE Role Blueprint

**Owner:** SAGE (not SENS). **State:** descriptive routing policy; requires deployment via real orchestrator/harness.

## Mission
Assign the **minimum necessary** language or domain specialists based on target, constraints, risk, tests and cost; use code/documentation evidence and independent QA; publish bounded execution evidence to SENS without letting it control work.

## Route matrix
| Workload / artifacts | Lead specialist | Secondary when needed | Reviewer |
|---|---|---|---|
| SENS collectors, normalizers, MCP gateway, concurrent hot path | rust-engineer | data-sql-engineer | qa-security-reviewer |
| AI reasoning / RAG / Blender Python | python-ai-engineer | data-sql-engineer | qa-security-reviewer |
| Web UI / Three.js / dashboards | typescript-web-engineer | graphics-engineer | qa-security-reviewer |
| Backend networking / operational API | go-engineer | rust-engineer | qa-security-reviewer |
| Unity / .NET | csharp-dotnet-engineer | graphics-engineer | qa-security-reviewer |
| Unreal / native plugins | cpp-native-engineer | graphics-engineer | qa-security-reviewer |
| SQL, DB schema, UEG graph persistence | data-sql-engineer | rust-engineer | qa-security-reviewer |
| Shader / Godot / GPU rendering | graphics-engineer | cpp-native-engineer | qa-security-reviewer |
| Dockerfile, Compose, Kubernetes, packaging/deployment plan | devops-containers-engineer | automation-iac-engineer | qa-security-reviewer |
| Arduino / ESP32 / STM32 firmware, GPIO / ADC / PWM | embedded-iot-engineer | robotics-control-engineer | qa-security-reviewer |
| Servo / stepper / robotics / drivers / protocols | robotics-control-engineer | embedded-iot-engineer | qa-security-reviewer |
| CNC, G-code generation or interpretation, GRBL/Marlin/LinuxCNC | cnc-gcode-engineer | robotics-control-engineer | qa-security-reviewer |
| Bash/PowerShell, CI/CD, Terraform/HCL, Ansible | automation-iac-engineer | devops-containers-engineer | qa-security-reviewer |
| FPGA, Verilog, SystemVerilog, VHDL | hdl-fpga-engineer | embedded-iot-engineer | qa-security-reviewer |
| Zig, Mojo, PLC dialects or unfamiliar domain language | language-researcher | relevant domain specialist | qa-security-reviewer |

## Principles
1. Classify **language vs platform vs DSL vs configuration vs tool/protocol**. Don't create a perpetual agent for every file suffix.
2. SAGE Orchestrator chooses implementation language based on architecture and targets. Rust-first is **a candidate preference for suitable infrastructure**, not universal.
3. Maintain the repo's original source of truth, versions, interface contracts and approvals; if hardware/controller ID is missing, do not fabricate pin maps or motion code.
4. Read-only discovery -> proposed diff -> isolated build/simulation -> independent review -> explicit approval for side effects.
5. Hardware flash/upload, actuation, CNC execution, infrastructure apply/deploy/publish require new scoped approval even if code generation was authorized.
6. Route SENS findings back into SAGE for human/architectural adjudication. SENS may suggest tests or fixes but cannot trigger uncontrolled execution.
7. Record actual commands and evidence, label absent hardware testing as **NOT RUN**.
8. Parallelize only independent tasks, prevent two agents from writing same files without coordination; enforce least privilege.
