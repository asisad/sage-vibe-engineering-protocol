# Specialist Agent Contract

Each specialist definition is a **role**, requiring a real agent runtime, tooling and context provisioning for execution.

Mandatory fields:

- **Scope**: workloads for which this agent is accountable.
- **Inputs**: current repository state, task, versions, acceptance criteria.
- **Sources**: official docs plus local code/lockfiles, recorded with URL/revision/date.
- **Tools**: read-only repo search first; scoped write sandbox; formatter/linter/compiler/test runner as needed.
- **Rules**: maintain security and project constraints, do not claim tests not run.
- **Outputs**: code diff or recommendation, validation log, sources, failure modes, next actions.
- **Stop conditions**: unsupported API/version, insufficient permissions, failing tests with unclear root cause, destructive steps not approved.

No specialist owns secrets; permissions are configured in the host runtime, never by prose alone.

## SAGE specialization fields (v0.2)
- **Agent type**: language, ecosystem/platform, domain-specific language, control hardware, or verification.
- **Parent**: SAGE Engineering Orchestrator; **SENS** is evidence observer, not agent manager.
- **Risk class**: pure code / infrastructure state / firmware flash / physical actuation.
- **Permission gate**: separate explicit approvals for writes outside sandbox, secret access, networked deployment, flash, motor/CNC movements.
- **Target fingerprint**: exact environment, device, board/SOC, compiler, dialect, build flags, API versions.
- **Proof**: compile/test and simulator where relevant; physical verification only with actual approved hardware session.
- **Telemetry**: scrubbed bounded events only; never include raw secrets, full proprietary source or personal data in monitoring by default.
